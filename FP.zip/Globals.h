#ifndef GLOBALS_H
#define GLOBALS_H

#include <SFML\Graphics.hpp>

#endif