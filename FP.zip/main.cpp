#include "Game.h"

int main() {
  Game game;
  game.create(100, 100, 5);
  game.run();
}